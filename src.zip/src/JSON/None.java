package org.json;

public interface None {
    /**
     * Negative One
     */
    public static final int none = -1;

}
