/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TwitterCounter;

import ERP.Basis.Database.ERPEntity;
import ERP.Basis.Database.ERPPrimaryKey;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import org.joda.time.DateTime;

/**
 *
 * @author KH
 */
public class CompanyLookupDetail implements ERPEntity{

    private String COMPANYNAME;
    private java.sql.Date RECORDDATE;
    private int FOLLOWERCOUNT;

    public String getCOMPANYNAME() {
        return COMPANYNAME;
    }

    public void setCOMPANYNAME(String COMPANYNAME) {
        this.COMPANYNAME = COMPANYNAME;
    }

    public int getFOLLOWERCOUNT() {
        return FOLLOWERCOUNT;
    }

    public void setFOLLOWERCOUNT(int FOLLOWERCOUNT) {
        this.FOLLOWERCOUNT = FOLLOWERCOUNT;
    }

    public Date getRECORDDATE() {
        return RECORDDATE;
    }

    public void setRECORDDATE(Date RECORDDATE) {
        this.RECORDDATE = RECORDDATE;
    }
    
    
    @Override
    public ERPPrimaryKey getPK() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void randInit() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int compareTo() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean equalsTuple(ERPEntity anotherERPEntity) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String name() {
        return "COMPANYLOOKUPDETAIL";
    }

    @Override
    public Collection<String> getFieldNames() {
        ArrayList<String> fields = new ArrayList<String>();
        fields.add("COMPANYNAME");
        fields.add("RECORDDATE");
        fields.add("FOLLOWERCOUNT");
        
        return fields;
    }

    @Override
    public void importFromMap(Map<String, Object> attributes) {
        if(attributes.containsKey("COMPANYNAME"))
            this.setCOMPANYNAME((String)attributes.get("COMPANYNAME"));
        if(attributes.containsKey("RECORDDATE")){
            Object date = attributes.get("RECORDDATE");
            //Convert everything to java.sql.date
            if(date instanceof Date){
                this.setRECORDDATE(new java.sql.Date(((Date)date).getTime()));
            }
            else if(date instanceof java.sql.Date){
                this.setRECORDDATE((java.sql.Date)date);
            }
            else if(date instanceof Long){
                this.setRECORDDATE(new java.sql.Date((Long)date));
            }
            else{
                //don't set a date if it is an unknown format
                System.out.println("Unknown format for date "+date.getClass().getName());
            }
        }
        if(attributes.containsKey("FOLLOWERCOUNT"))
            this.setFOLLOWERCOUNT((Integer)attributes.get("FOLLOWERCOUNT"));
    }

    @Override
    public Map<String, Object> exportAsMap() {
        Map<String, Object> mapOutput = new HashMap<String,Object>();
        mapOutput.put("COMPANYNAME", this.getCOMPANYNAME());
        mapOutput.put("RECORDDATE", this.getRECORDDATE());
        mapOutput.put("FOLLOWERCOUNT", this.getFOLLOWERCOUNT());
        
        return mapOutput;
    }

    @Override
    public int compareTo(Object o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
