/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ERP.Basis.Database;

/**
 *
 * @author KH
 */
public interface JoinEntity {
    
}
