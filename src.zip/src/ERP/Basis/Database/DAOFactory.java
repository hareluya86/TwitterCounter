/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ERP.Basis.Database;

//import Basis.Database.MySQLPersistence.DAOFactoryMySQL;
import java.util.HashMap;

/**
 *
 * @author KH
 */

public abstract class DAOFactory {
/*  
    public static enum DBType { MYSQL, ORACLE };
    protected HashMap DBConfig = new HashMap<String,String>();
    
    /*
     * For all new implementation of DBMS, just need to override this method
     */
    protected abstract void initDB();
    /*
    public static DAOFactory getDAOFactory(DBType databaseType){
        switch(databaseType){
            case MYSQL : return new DAOFactoryMySQL();
            case ORACLE : 
            default : return null;
        }
    }
    
    public static DAOFactory getDAOFactory(){
        DAOFactory daofactory = getDAOFactory(DBType.MYSQL);
        return daofactory;
    }
    
    public abstract DAO getDAO();
*/
}
